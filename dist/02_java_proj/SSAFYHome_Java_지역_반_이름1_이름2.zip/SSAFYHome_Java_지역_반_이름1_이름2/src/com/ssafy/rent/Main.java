package com.ssafy.rent;

import com.ssafy.rent.view.HomeInfoView;

public class Main {
	public static void main(String[] args) {
		new HomeInfoView();
	}
}
