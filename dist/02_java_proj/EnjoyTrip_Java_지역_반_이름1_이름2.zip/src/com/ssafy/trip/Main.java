package com.ssafy.trip;

import com.ssafy.trip.view.TripInfoView;

public class Main {

	public static void main(String[] args) {
		new TripInfoView();
	}
	
}
